# Extreme Quality Clean

Website for Extreme Quality Clean Inc. (Sherman Oaks / Los Angeles).

## Run locally

```bash
npm install
npm run dev
```

Opens on port 8080.

## Production build

```bash
npm run build
npm run preview
```

## Notes

- No public prices. Quote form emails the team.
- Google rating on the site is 5.0 from 17 reviews, matching the Google listing.
- Articles live in `src/content/articles/`. Images and videos live in `public/`.
