# Extreme Quality Clean

Website for Extreme Quality Clean Inc. (Sherman Oaks / Los Angeles).

## Run locally

```bash
npm install
npm run dev
```

Opens on port 8080.

## Production build

```bash
npm run build
npm run preview
```

## Notes

- Office address on the site: 15130 Ventura Blvd, Sherman Oaks, CA 91403.
- Quote form emails extremequalitycleaninc@gmail.com.
- Neighborhood pages: Van Nuys, Sherman Oaks, Encino, Studio City.
- Google rating on the site is 5.0 from 17 reviews.
